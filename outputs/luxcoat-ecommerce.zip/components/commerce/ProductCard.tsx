import Image from "next/image";
import Link from "next/link";
import { AddToCartButton } from "@/components/commerce/AddToCartButton";
import { formatMoney } from "@/lib/money";
import type { Product } from "@/lib/types";

export function ProductCard({ product }: { product: Product }) {
  return (
    <article className="glass-panel group overflow-hidden rounded-[2rem]">
      <Link className="relative block aspect-square overflow-hidden bg-black/40" href={`/product/${product.slug}`}>
        <Image
          alt={product.title}
          className="object-cover transition duration-700 group-hover:scale-105"
          fill
          sizes="(min-width: 1024px) 420px, 100vw"
          src={product.imageUrl}
        />
      </Link>
      <div className="p-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-cobalt">
              {product.sizeMl} ml
            </p>
            <h3 className="mt-2 text-2xl font-black text-white">{product.title}</h3>
          </div>
          <p className="text-xl font-black text-white">
            {formatMoney(product.priceCents, product.currency)}
          </p>
        </div>
        <p className="mt-4 line-clamp-3 text-sm leading-6 text-slate-400">
          {product.description}
        </p>
        <div className="mt-6 flex flex-col gap-3 sm:flex-row">
          <AddToCartButton className="btn-primary flex-1" product={product} />
          <Link className="btn-secondary flex-1" href={`/product/${product.slug}`}>
            View Product
          </Link>
        </div>
      </div>
    </article>
  );
}
