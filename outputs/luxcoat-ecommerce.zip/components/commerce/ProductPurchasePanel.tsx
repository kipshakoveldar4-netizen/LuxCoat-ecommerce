"use client";

import { Minus, Plus, ShieldCheck, Truck } from "lucide-react";
import { useState } from "react";
import { AddToCartButton } from "@/components/commerce/AddToCartButton";
import { BuyNowButton } from "@/components/commerce/BuyNowButton";
import { formatMoney } from "@/lib/money";
import type { Product } from "@/lib/types";

export function ProductPurchasePanel({ product }: { product: Product }) {
  const [quantity, setQuantity] = useState(1);

  return (
    <div className="glass-panel rounded-[2rem] p-5 sm:p-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <p className="text-sm text-slate-400">Size</p>
          <p className="text-lg font-bold text-white">{product.sizeMl} ml bottle</p>
        </div>
        <div className="rounded-full border border-cobalt/40 bg-cobalt/10 px-4 py-2 text-sm font-bold text-cobalt">
          {product.inventoryQuantity} in stock
        </div>
      </div>

      <div className="mt-6 flex flex-wrap items-center justify-between gap-5">
        <div>
          <p className="text-sm text-slate-400">Price</p>
          <p className="text-4xl font-black text-white">
            {formatMoney(product.priceCents, product.currency)}
          </p>
        </div>
        <div className="flex items-center rounded-full border border-white/15 bg-white/10 p-1">
          <button
            aria-label="Decrease quantity"
            className="flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/10"
            onClick={() => setQuantity((value) => Math.max(1, value - 1))}
            type="button"
          >
            <Minus size={16} />
          </button>
          <span className="w-10 text-center text-sm font-bold text-white">{quantity}</span>
          <button
            aria-label="Increase quantity"
            className="flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/10"
            onClick={() => setQuantity((value) => Math.min(24, value + 1))}
            type="button"
          >
            <Plus size={16} />
          </button>
        </div>
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        <AddToCartButton className="btn-primary w-full" product={product} quantity={quantity} />
        <BuyNowButton product={product} quantity={quantity} />
      </div>

      <div className="mt-6 grid gap-3 text-sm text-slate-300">
        <div className="flex items-center gap-3">
          <Truck className="text-cobalt" size={18} />
          Ships from China with tracking to USA, UK, and Europe.
        </div>
        <div className="flex items-center gap-3">
          <ShieldCheck className="text-cobalt" size={18} />
          Prepared for PayPal and 2Checkout secure payment integration.
        </div>
      </div>
    </div>
  );
}
