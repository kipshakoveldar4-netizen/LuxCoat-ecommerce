"use client";

import { Minus, Plus, ShoppingBag, Trash2 } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import {
  readCart,
  removeFromCart,
  updateCartQuantity
} from "@/components/commerce/cart-store";
import { formatMoney } from "@/lib/money";
import type { CartItem } from "@/lib/types";

export function CartPageClient() {
  const [items, setItems] = useState<CartItem[]>([]);

  useEffect(() => {
    const refresh = () => setItems(readCart());
    refresh();
    window.addEventListener("luxcoat-cart", refresh);
    return () => window.removeEventListener("luxcoat-cart", refresh);
  }, []);

  const subtotal = useMemo(
    () => items.reduce((total, item) => total + item.priceCents * item.quantity, 0),
    [items]
  );
  const shipping = subtotal >= 7000 || subtotal === 0 ? 0 : 695;
  const total = subtotal + shipping;

  return (
    <section className="page-shell section">
      <p className="eyebrow">Cart</p>
      <h1 className="section-title">Review your coating order.</h1>

      {items.length === 0 ? (
        <div className="glass-panel mt-10 rounded-[2rem] p-8 text-center">
          <ShoppingBag className="mx-auto text-cobalt" size={38} />
          <h2 className="mt-5 text-2xl font-black text-white">Your cart is empty.</h2>
          <p className="mx-auto mt-3 max-w-md text-sm leading-7 text-slate-400">
            Add LuxCoat Liquid Glass to start a USA, UK, or Europe checkout flow.
          </p>
          <Link className="btn-primary mt-6" href="/shop">
            Shop LuxCoat
          </Link>
        </div>
      ) : (
        <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_420px]">
          <div className="grid gap-4">
            {items.map((item) => (
              <article
                className="glass-panel grid gap-5 rounded-[1.6rem] p-4 sm:grid-cols-[120px_1fr_auto]"
                key={item.productId}
              >
                <div className="relative aspect-square overflow-hidden rounded-2xl bg-black/40">
                  <Image alt={item.title} className="object-cover" fill sizes="120px" src={item.imageUrl} />
                </div>
                <div>
                  <p className="text-xs font-bold uppercase tracking-[0.18em] text-cobalt">
                    {item.sizeMl} ml · {item.sku}
                  </p>
                  <h2 className="mt-2 text-xl font-black text-white">{item.title}</h2>
                  <p className="mt-2 text-sm text-slate-400">
                    {formatMoney(item.priceCents, item.currency)} each
                  </p>
                  <button
                    className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-slate-400 hover:text-white"
                    onClick={() => removeFromCart(item.productId)}
                    type="button"
                  >
                    <Trash2 size={16} />
                    Remove
                  </button>
                </div>
                <div className="flex items-center gap-3 sm:flex-col sm:items-end sm:justify-between">
                  <div className="flex items-center rounded-full border border-white/15 bg-white/10 p-1">
                    <button
                      aria-label="Decrease quantity"
                      className="flex h-9 w-9 items-center justify-center rounded-full text-white hover:bg-white/10"
                      onClick={() => updateCartQuantity(item.productId, item.quantity - 1)}
                      type="button"
                    >
                      <Minus size={15} />
                    </button>
                    <span className="w-9 text-center text-sm font-bold text-white">
                      {item.quantity}
                    </span>
                    <button
                      aria-label="Increase quantity"
                      className="flex h-9 w-9 items-center justify-center rounded-full text-white hover:bg-white/10"
                      onClick={() => updateCartQuantity(item.productId, item.quantity + 1)}
                      type="button"
                    >
                      <Plus size={15} />
                    </button>
                  </div>
                  <p className="text-lg font-black text-white">
                    {formatMoney(item.priceCents * item.quantity, item.currency)}
                  </p>
                </div>
              </article>
            ))}
          </div>
          <aside className="glass-panel h-fit rounded-[2rem] p-6">
            <h2 className="text-2xl font-black text-white">Order Summary</h2>
            <div className="mt-6 grid gap-4 text-sm">
              <div className="flex justify-between text-slate-300">
                <span>Subtotal</span>
                <span>{formatMoney(subtotal, items[0]?.currency ?? "USD")}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Shipping from China</span>
                <span>{shipping === 0 ? "Free" : formatMoney(shipping, items[0]?.currency ?? "USD")}</span>
              </div>
              <div className="border-t border-white/10 pt-4">
                <div className="flex justify-between text-lg font-black text-white">
                  <span>Total</span>
                  <span>{formatMoney(total, items[0]?.currency ?? "USD")}</span>
                </div>
              </div>
            </div>
            <Link className="btn-primary mt-7 w-full" href="/checkout">
              Checkout
            </Link>
          </aside>
        </div>
      )}
    </section>
  );
}
