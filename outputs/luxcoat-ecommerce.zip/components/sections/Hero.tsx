import { ArrowRight, ShieldCheck, Sparkles, Timer } from "lucide-react";
import Image from "next/image";
import Link from "next/link";

export function Hero() {
  return (
    <section className="relative min-h-[calc(100vh-7rem)] overflow-hidden">
      <Image
        alt="LuxCoat Liquid Glass with glossy black car"
        className="object-cover"
        fill
        priority
        sizes="100vw"
        src="/images/luxcoat-hero.png"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-black via-black/78 to-black/10" />
      <div className="absolute inset-0 bg-gradient-to-t from-midnight via-transparent to-transparent" />
      <div className="page-shell relative flex min-h-[calc(100vh-7rem)] items-center py-16">
        <div className="max-w-2xl">
          <p className="eyebrow">LuxCoat Liquid Glass · 237 ml</p>
          <h1 className="mt-5 text-5xl font-black leading-[1.02] text-white sm:text-6xl lg:text-7xl">
            Mirror gloss protection in about 15 minutes.
          </h1>
          <p className="mt-6 max-w-xl text-lg leading-8 text-slate-200">
            Restore shine, add a deep wet-look finish, and help protect automotive
            paint from light scratches and UV damage with a premium hand-applied
            coating.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Link className="btn-primary" href="/product/luxcoat-liquid-glass-237ml">
              Shop LuxCoat
              <ArrowRight size={18} />
            </Link>
            <Link className="btn-secondary" href="/before-after">
              See Before / After
            </Link>
          </div>
          <div className="mt-8 grid max-w-2xl gap-3 sm:grid-cols-3">
            {[
              { icon: Timer, label: "15 min application" },
              { icon: Sparkles, label: "6-7 month effect" },
              { icon: ShieldCheck, label: "UV & gloss shield" }
            ].map((item) => {
              const Icon = item.icon;
              return (
                <div
                  className="rounded-2xl border border-white/15 bg-white/10 px-4 py-3 backdrop-blur"
                  key={item.label}
                >
                  <Icon className="text-cobalt" size={19} />
                  <p className="mt-2 text-xs font-bold uppercase leading-5 tracking-[0.14em] text-slate-200">
                    {item.label}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
