"use client";

import Image from "next/image";
import { useState } from "react";

export function BeforeAfterSlider() {
  const [value, setValue] = useState(52);

  return (
    <div className="glass-panel overflow-hidden rounded-[2rem]">
      <div className="relative aspect-[16/9] min-h-[280px]">
        <Image
          alt="LuxCoat coated vehicle after application"
          className="object-cover"
          fill
          sizes="(min-width: 1024px) 1080px, 100vw"
          src="/images/luxcoat-hero.png"
        />
        <div
          className="absolute inset-0 overflow-hidden"
          style={{ width: `${value}%` }}
        >
          <Image
            alt="Vehicle finish before LuxCoat application"
            className="object-cover grayscale brightness-[0.48] contrast-[0.9]"
            fill
            sizes="(min-width: 1024px) 1080px, 100vw"
            src="/images/luxcoat-hero.png"
          />
        </div>
        <div
          className="absolute top-0 h-full w-1 bg-cobalt shadow-glow"
          style={{ left: `${value}%` }}
        />
        <div className="absolute left-5 top-5 rounded-full bg-black/70 px-4 py-2 text-xs font-bold uppercase tracking-[0.2em] text-slate-300">
          Before
        </div>
        <div className="absolute right-5 top-5 rounded-full bg-cobalt px-4 py-2 text-xs font-bold uppercase tracking-[0.2em] text-white">
          After
        </div>
      </div>
      <div className="border-t border-white/10 p-5">
        <input
          aria-label="Compare before and after"
          className="w-full accent-cobalt"
          max="82"
          min="18"
          onChange={(event) => setValue(Number(event.target.value))}
          type="range"
          value={value}
        />
      </div>
    </div>
  );
}
