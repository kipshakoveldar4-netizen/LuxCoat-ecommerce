import { ChevronRight, Star } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { BeforeAfterSlider } from "@/components/sections/BeforeAfterSlider";
import { ProductCard } from "@/components/commerce/ProductCard";
import {
  applicationSteps,
  certificates,
  faqs,
  howItWorks,
  product,
  reviews
} from "@/lib/content";

export function BeforeAfterSection() {
  return (
    <section className="section">
      <div className="page-shell">
        <div className="grid gap-10 lg:grid-cols-[0.75fr_1.25fr] lg:items-center">
          <div>
            <p className="eyebrow">Before / After</p>
            <h2 className="section-title">From flat paint to high-definition reflections.</h2>
            <p className="section-copy">
              Drag the comparison bar to see the kind of richer contrast, clearer
              reflection, and deeper black finish LuxCoat is designed to create.
            </p>
            <Link className="btn-secondary mt-7" href="/before-after">
              Open Gallery
              <ChevronRight size={18} />
            </Link>
          </div>
          <BeforeAfterSlider />
        </div>
      </div>
    </section>
  );
}

export function HowItWorksSection() {
  return (
    <section className="section bg-black/25">
      <div className="page-shell">
        <p className="eyebrow">How It Works</p>
        <h2 className="section-title">A glass-like layer that intensifies gloss.</h2>
        <div className="mt-10 grid gap-4 md:grid-cols-4">
          {howItWorks.map((item, index) => (
            <article className="glass-panel rounded-[1.5rem] p-6" key={item.title}>
              <span className="text-sm font-black text-cobalt">0{index + 1}</span>
              <h3 className="mt-5 text-xl font-bold text-white">{item.title}</h3>
              <p className="mt-3 text-sm leading-6 text-slate-400">{item.text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

export function ApplyStepsSection() {
  return (
    <section className="section">
      <div className="page-shell">
        <div className="grid gap-10 lg:grid-cols-[1fr_0.9fr] lg:items-center">
          <div>
            <p className="eyebrow">3 Step Application</p>
            <h2 className="section-title">Hand-applied, fast, and repeatable.</h2>
            <div className="mt-8 grid gap-4">
              {applicationSteps.map((step) => {
                const Icon = step.icon;
                return (
                  <div className="glass-panel rounded-[1.5rem] p-5" key={step.title}>
                    <div className="flex gap-4">
                      <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-cobalt/35 bg-cobalt/15 text-cobalt">
                        <Icon size={22} />
                      </span>
                      <div>
                        <h3 className="text-lg font-bold text-white">{step.title}</h3>
                        <p className="mt-2 text-sm leading-6 text-slate-400">{step.text}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          <div className="relative min-h-[500px] overflow-hidden rounded-[2rem] border border-white/15 bg-black">
            <Image
              alt="LuxCoat bottle on dark detailing surface"
              className="object-cover"
              fill
              sizes="(min-width: 1024px) 520px, 100vw"
              src="/images/luxcoat-product.png"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
            <div className="absolute bottom-6 left-6 right-6 rounded-3xl border border-white/15 bg-black/55 p-5 backdrop-blur-xl">
              <p className="text-sm font-semibold text-slate-300">
                Best results: wash, dry, apply thin, buff clear, and keep dry for 24 hours.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export function FeaturedProductSection() {
  return (
    <section className="section bg-black/25">
      <div className="page-shell">
        <div className="grid gap-10 lg:grid-cols-[0.75fr_1.25fr] lg:items-center">
          <div>
            <p className="eyebrow">Featured Product</p>
            <h2 className="section-title">One premium bottle. Months of gloss.</h2>
            <p className="section-copy">
              The 237 ml bottle is sized for repeat detailing and simple home application.
              Add it to cart or open the full product page for gallery, instructions,
              shipping details, certificates, reviews, and FAQ.
            </p>
          </div>
          <ProductCard product={product} />
        </div>
      </div>
    </section>
  );
}

export function ReviewsSection() {
  return (
    <section className="section">
      <div className="page-shell">
        <p className="eyebrow">Customer Reviews</p>
        <h2 className="section-title">Detailing results drivers can feel.</h2>
        <div className="mt-10 grid gap-4 md:grid-cols-3">
          {reviews.map((review) => (
            <article className="glass-panel rounded-[1.6rem] p-6" key={review.name}>
              <div className="flex gap-1 text-cobalt">
                {Array.from({ length: review.rating }).map((_, index) => (
                  <Star fill="currentColor" key={index} size={17} />
                ))}
              </div>
              <p className="mt-5 text-base leading-7 text-slate-200">“{review.text}”</p>
              <p className="mt-5 text-sm font-bold text-white">{review.name}</p>
              <p className="mt-1 text-xs uppercase tracking-[0.16em] text-slate-500">
                {review.market}
              </p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

export function FaqSection() {
  return (
    <section className="section bg-black/25">
      <div className="page-shell">
        <p className="eyebrow">FAQ</p>
        <h2 className="section-title">Clear answers before checkout.</h2>
        <div className="mt-10 grid gap-4 lg:grid-cols-2">
          {faqs.map((item) => (
            <details className="glass-panel rounded-[1.4rem] p-5" key={item.question}>
              <summary className="cursor-pointer list-none text-lg font-bold text-white">
                {item.question}
              </summary>
              <p className="mt-4 text-sm leading-7 text-slate-400">{item.answer}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}

export function CertificatesSection() {
  return (
    <section className="section">
      <div className="page-shell">
        <div className="glass-panel overflow-hidden rounded-[2rem] p-6 sm:p-8">
          <div className="grid gap-8 lg:grid-cols-[0.8fr_1.2fr] lg:items-center">
            <div>
              <p className="eyebrow">Certificates / SDS</p>
              <h2 className="section-title">Documentation-ready before launch.</h2>
              <p className="section-copy">
                The site includes a dedicated certificates and SDS area for safety
                data, batch documentation, and import compliance assets.
              </p>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              {certificates.map((item) => {
                const Icon = item.icon;
                return (
                  <Link
                    className="rounded-[1.5rem] border border-white/10 bg-white/[0.05] p-5 transition hover:border-cobalt/50"
                    href={item.href}
                    key={item.title}
                  >
                    <Icon className="text-cobalt" size={26} />
                    <h3 className="mt-4 text-lg font-bold text-white">{item.title}</h3>
                    <p className="mt-2 text-sm leading-6 text-slate-400">{item.text}</p>
                  </Link>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
