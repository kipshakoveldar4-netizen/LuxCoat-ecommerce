import type { Metadata } from "next";
import { Download, FileCheck2, ShieldCheck } from "lucide-react";

export const metadata: Metadata = {
  title: "Certificates / SDS",
  description: "LuxCoat certificates and safety data sheet area."
};

export default function CertificatesPage() {
  return (
    <section className="page-shell section">
      <p className="eyebrow">Certificates / SDS</p>
      <h1 className="section-title">Launch-ready document center.</h1>
      <p className="section-copy">
        Upload final SDS, certificate of analysis, batch records, and import
        documents here before production launch.
      </p>
      <div className="mt-10 grid gap-5 md:grid-cols-2">
        {[
          {
            icon: FileCheck2,
            title: "Safety Data Sheet",
            text: "Placeholder for SDS PDF covering handling, storage, hazards, and emergency guidance."
          },
          {
            icon: ShieldCheck,
            title: "Compliance Certificates",
            text: "Placeholder for batch, manufacturer, and market-specific documentation."
          }
        ].map((item) => {
          const Icon = item.icon;
          return (
            <article className="glass-panel rounded-[1.6rem] p-6" key={item.title}>
              <Icon className="text-cobalt" size={30} />
              <h2 className="mt-5 text-2xl font-black text-white">{item.title}</h2>
              <p className="mt-3 text-sm leading-7 text-slate-400">{item.text}</p>
              <button className="btn-secondary mt-6" type="button">
                <Download size={18} />
                Upload Required
              </button>
            </article>
          );
        })}
      </div>
    </section>
  );
}
