import type { Metadata } from "next";
import { BeforeAfterSlider } from "@/components/sections/BeforeAfterSlider";

export const metadata: Metadata = {
  title: "Before / After",
  description: "Compare LuxCoat Liquid Glass before and after finish."
};

export default function BeforeAfterPage() {
  return (
    <section className="page-shell section">
      <p className="eyebrow">Before / After</p>
      <h1 className="section-title">See the finish transform.</h1>
      <p className="section-copy">
        A premium coating experience should be visible: darker contrast, sharper
        reflections, and a slick liquid-glass look.
      </p>
      <div className="mt-10">
        <BeforeAfterSlider />
      </div>
    </section>
  );
}
