import {
  Award,
  BadgeCheck,
  Car,
  Clock3,
  Droplets,
  FileCheck2,
  Hand,
  ShieldCheck,
  Sparkles,
  Sun,
  Truck,
  WandSparkles
} from "lucide-react";
import type { Product } from "@/lib/types";

export const site = {
  name: "LuxCoat",
  url: "https://luxcoat.example",
  announcement: "Worldwide shipping from China | USA & Europe available"
};

export const product: Product = {
  id: "prod_luxcoat_237",
  slug: "luxcoat-liquid-glass-237ml",
  sku: "LC-LG-237",
  title: "LuxCoat Liquid Glass",
  description:
    "A premium hand-applied automotive liquid glass coating that restores shine, creates a deep glossy finish, and helps protect paintwork from light scratches and UV damage.",
  sizeMl: 237,
  priceCents: 3495,
  currency: "USD",
  inventoryQuantity: 420,
  imageUrl: "/images/luxcoat-product.png",
  gallery: [
    "/images/luxcoat-product.png",
    "/images/luxcoat-hero.png",
    "/images/luxcoat-product.png"
  ],
  benefits: [
    "Deep wet-look gloss",
    "Hand-applied in around 15 minutes",
    "Up to 6-7 months effect duration",
    "Helps protect from UV damage",
    "Reduces appearance of light scratches",
    "Suitable for cars, motorcycles, and painted trim"
  ]
};

export const navItems = [
  { href: "/shop", label: "Shop" },
  { href: "/how-to-use", label: "How To Use" },
  { href: "/before-after", label: "Before / After" },
  { href: "/reviews", label: "Reviews" },
  { href: "/faq", label: "FAQ" },
  { href: "/contact", label: "Contact" }
];

export const benefits = [
  {
    icon: Sparkles,
    title: "Restores Shine",
    text: "Revives tired paintwork with a darker, glossier finish that feels showroom-ready."
  },
  {
    icon: ShieldCheck,
    title: "Protective Layer",
    text: "Adds a slick liquid-glass barrier against UV exposure, grime, and light swirl marks."
  },
  {
    icon: Clock3,
    title: "15 Minute Apply",
    text: "Designed for hand application, no machine polisher or workshop setup required."
  },
  {
    icon: Droplets,
    title: "Hydrophobic Finish",
    text: "Water beads and rolls away more easily, helping your car stay cleaner between washes."
  }
];

export const trustBadges = [
  { icon: Truck, label: "Ships from China" },
  { icon: Car, label: "USA, UK & Europe" },
  { icon: Award, label: "Premium detailing finish" },
  { icon: BadgeCheck, label: "Secure checkout ready" }
];

export const howItWorks = [
  {
    title: "Clean",
    text: "Wash and dry the paint so the coating bonds cleanly."
  },
  {
    title: "Bond",
    text: "LuxCoat spreads into a thin glass-like layer by hand."
  },
  {
    title: "Gloss",
    text: "The surface gains a deeper reflective finish and slick touch."
  },
  {
    title: "Protect",
    text: "Enjoy durable shine and UV protection for up to 6-7 months."
  }
];

export const applicationSteps = [
  {
    icon: Hand,
    title: "Apply",
    text: "Add a small amount to a microfiber applicator and spread evenly over one panel."
  },
  {
    icon: WandSparkles,
    title: "Buff",
    text: "Let it haze briefly, then buff with a clean microfiber towel until the finish clears."
  },
  {
    icon: Sun,
    title: "Cure",
    text: "Keep the surface dry for best results and avoid washing for 24 hours."
  }
];

export const faqs = [
  {
    question: "How long does LuxCoat last?",
    answer:
      "The effect can last up to 6-7 months depending on climate, washing frequency, and surface preparation."
  },
  {
    question: "Can I apply it by hand?",
    answer:
      "Yes. LuxCoat is designed for hand application with a microfiber applicator and towel."
  },
  {
    question: "How long does application take?",
    answer:
      "Most vehicles can be coated in around 15 minutes after washing and drying."
  },
  {
    question: "Does it remove deep scratches?",
    answer:
      "No. It helps reduce the visibility of light swirl marks and adds protection, but deep scratches need paint correction."
  },
  {
    question: "Where do orders ship from?",
    answer:
      "Orders ship from China to the USA, UK, and European markets with tracking once fulfilled."
  }
];

export const reviews = [
  {
    name: "Marcus T.",
    market: "California, USA",
    rating: 5,
    text: "The gloss is noticeably deeper after one quick hand application. It made my black coupe look freshly detailed."
  },
  {
    name: "Amelia R.",
    market: "Manchester, UK",
    rating: 5,
    text: "Easy to buff and the water beading is excellent. The finish still looked slick after several washes."
  },
  {
    name: "Jonas K.",
    market: "Berlin, Germany",
    rating: 5,
    text: "Feels more premium than the quick sprays I have tried. The bottle and application process are straightforward."
  }
];

export const certificates = [
  {
    icon: FileCheck2,
    title: "Safety Data Sheet",
    text: "SDS placeholder prepared for upload before launch.",
    href: "/certificates-sds"
  },
  {
    icon: ShieldCheck,
    title: "Compliance Pack",
    text: "Batch documentation, composition notes, and market-specific import files can be attached in admin.",
    href: "/certificates-sds"
  }
];

export const markets = [
  { country: "United States", currency: "USD", symbol: "$" },
  { country: "United Kingdom", currency: "GBP", symbol: "£" },
  { country: "Europe", currency: "EUR", symbol: "€" }
];
